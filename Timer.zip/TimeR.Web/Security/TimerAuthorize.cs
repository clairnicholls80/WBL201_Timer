﻿using System;
using System.Linq;
using System.Web.Mvc;
using TimeR.ObjectModel.Entities;
using TimeR.ObjectModel.Enums;
using TimeR.ObjectModel;

namespace TimeR.Web.Security
{
    public class TimerAuthorize : AuthorizeAttribute
    {
        /// <summary>
        /// Admins always have access, so these don't need to be explicitly
        /// specified when decorating controllers/actions
        /// </summary>
        private static readonly string[] RolesWhoAlwaysHaveAccess =
            new[] { Role.Administrator.ToString() };

        public TimerAuthorize(params object[] roles)
        {
            if (roles.Any(x => x.GetType() != typeof(Role)))
                throw new ArgumentException("The roles parameter may only contain enums", nameof(roles));

            var validRoles = roles.Select(x => Enum.GetName(x.GetType(), x)).ToList();
            validRoles.AddRange(RolesWhoAlwaysHaveAccess);
            Roles = string.Join(",", validRoles);
        }

        protected override void HandleUnauthorizedRequest(AuthorizationContext filterContext)
        {
            using (var ctx = new TimerContext())
            {
                var username = filterContext.HttpContext.User.Identity.Name;
                username = username.Substring(3, username.Length - 3); //remove 'cc\\' domain from username
                var user = ctx.Staff.SingleOrDefault(x => x.Username == username);

                ctx.SaveChanges();

                if (!filterContext.HttpContext.User.Identity.IsAuthenticated)
                {
                    base.HandleUnauthorizedRequest(filterContext);
                }
                else
                {
                    filterContext.Result = new ViewResult{ ViewName = "AccessDenied" };
                }
            }
        }
    }
}