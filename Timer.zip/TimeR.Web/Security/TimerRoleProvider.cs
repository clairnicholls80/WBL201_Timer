﻿using System;
using System.Linq;
using System.Web.Security;
using TimeR.ObjectModel.Entities;
using TimeR.ObjectModel.Enums;
using TimeR.ObjectModel;

namespace TimeR.Web.Security
{
    public class TimerRoleProvider : RoleProvider
    {
        public override bool IsUserInRole(string username, string roleName)
        {
            using (var ctx = new TimerContext())
            {
                username = username.Substring(3, username.Length - 3); //remove 'cc\\' domain from username
                var user = ctx.Staff.SingleOrDefault(x => x.Username == username);
                if (user == null) return false;

                return user.Role.ToString() == roleName;
            }
        }

        public override string[] GetRolesForUser(string username)
        {
            using (var ctx = new TimerContext())
            {
                username = username.Substring(3, username.Length - 3); //remove 'cc\\' domain from username
                var user = ctx.Staff.SingleOrDefault(x => x.Username == username);
                if (user == null ) return new string[] {};

                return  new[] {user.Role.ToString()};
            }
        }

        public override void CreateRole(string roleName)
        {
            throw new NotImplementedException();
        }

        public override bool DeleteRole(string roleName, bool throwOnPopulatedRole)
        {
            throw new NotImplementedException();
        }

        public override bool RoleExists(string roleName)
        {
            throw new NotImplementedException();
        }

        public override void AddUsersToRoles(string[] usernames, string[] roleNames)
        {
            throw new NotImplementedException();
        }

        public override void RemoveUsersFromRoles(string[] usernames, string[] roleNames)
        {
            throw new NotImplementedException();
        }

        public override string[] GetUsersInRole(string roleName)
        {
            throw new NotImplementedException();
        }

        public override string[] GetAllRoles()
        {
            throw new NotImplementedException();
        }

        public override string[] FindUsersInRole(string roleName, string usernameToMatch)
        {
            throw new NotImplementedException();
        }

        public override string ApplicationName { get; set; }
    }
}