﻿using System.Linq;
using System.Security.Principal;
using TimeR.ObjectModel.Enums;

namespace TimeR.Web.Security
{
    public static class PrincipalExtensions
    {
        /// <summary>
        /// True if user is in the Administrator or Developer role
        /// </summary>
        /// <param name="principal"></param>
        /// <returns></returns>
        public static bool IsInAdminRole(this IPrincipal principal)
        {
            return principal.IsInRole(Role.Administrator.ToString());
        }

        /// <summary>
        /// True if user is in any role, excluding organisations
        /// </summary>
        /// <param name="principal"></param>
        /// <returns></returns>
        public static bool IsInAnyRole(this IPrincipal principal)
        {
            if (principal == null) return false;
            if (principal.IsInRole(Role.User.ToString())) return true;
            if (principal.IsInRole(Role.Administrator.ToString())) return true;
            return false;
        }

        /// <summary>
        /// True if user is in any of the supplied roles
        /// </summary>
        /// <param name="principal"></param>
        /// <param name="roles"></param>
        /// <returns></returns>
        public static bool IsInAnyOfTheseRole(this IPrincipal principal, params string[] roles)
        {
            return roles.Any(principal.IsInRole);
        }
    }
}