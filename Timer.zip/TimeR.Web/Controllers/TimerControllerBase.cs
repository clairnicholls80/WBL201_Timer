﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity.Validation;
using TimeR.ObjectModel;
using Timer.Web.ViewModels;
using TimeR.ObjectModel.Entities;
using System.Globalization;

namespace TimeR.Web.Controllers
{
    public class TimerControllerBase : Controller
    {

        /// <summary>
        /// Reference to the current data context.
        /// </summary>
        protected TimerContext Context { get; set; }

        /// <summary>
        /// Returns true if this is an ajax request.
        /// </summary>
        /// <returns>True if ajax request.</returns>
        protected bool IsAjax()
        {
            return Request.IsAjaxRequest();
        }

        protected override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            Context = new TimerContext();

            base.OnActionExecuting(filterContext);
        }

        protected override void OnActionExecuted(ActionExecutedContext filterContext)
        {
            Context.Dispose();
            Context = null;

            base.OnActionExecuted(filterContext);
        }

        //protected override void OnAuthorization(AuthorizationContext filterContext)
        //{
        //    if (User.IsInRole("None")) filterContext.Result = new ViewResult { ViewName = "AccessDenied" };
        //    base.OnAuthorization(filterContext);
        //}

        public void AddValidationErrorsToModelState(DbEntityValidationException e)
        {
            foreach (var entityValidationError in e.EntityValidationErrors)
            {
                foreach (var error in entityValidationError.ValidationErrors)
                {
                    ModelState.AddModelError(error.PropertyName, error.ErrorMessage);
                }
            }
        }

        /// <summary>
        /// Gets an entity that is in the progress of being created or edited.
        /// </summary>
        /// <typeparam name="T">Entity Class</typeparam>
        /// <param name="condition">Matching condition</param>
        /// <returns>Entity from cache, otherwise null</returns>
        protected T GetCachedEntity<T>(Func<T, bool> condition) where T : class
        {
            var type = typeof(T).Name;
            var sessionLabel = string.Format("{0}-entity", type.ToLower());
            var item = Session[sessionLabel] as T;
            if (item != null && condition(item))
            {
                return item;
            }
            return null;
        }

        /// <summary>
        /// Saves an entity to a session veriable for later reference.
        /// </summary>
        /// <typeparam name="T">Entity Class</typeparam>
        /// <param name="entity">Entity to be cached</param>
        protected void CacheEntity<T>(T entity) where T : class
        {
            var type = typeof(T).Name;
            var sessionLabel = string.Format("{0}-entity", type.ToLower());
            Session[sessionLabel] = entity;
        }

        protected void ClearEntityCache<T>() where T : class
        {
            var type = typeof(T).Name;
            var sessionLabel = string.Format("{0}-entity", type.ToLower());
            Session[sessionLabel] = null;
        }

        protected ActionResult ItemInUseError(string entityType, int entityId, string displayName, string returnController)
        {
            var itemInUse = new ItemInUse { EntityType = entityType, EntityId = entityId, DisplayName = displayName, ReturnController = returnController };
            Session["ItemInUse"] = itemInUse;

            return RedirectToAction("ItemInUse", "Message");
        }

        protected ActionResult MissingItemError(string entityType, int entityId, string returnController)
        {
            var missingItem = new MissingItem { EntityType = entityType, EntityId = entityId, ReturnController = returnController };
            Session["MissingItem"] = missingItem;

            return RedirectToAction("MissingItem", "Message");
        }

        protected ActionResult UpdatedItemError(string entityType, int entityId, string returnController)
        {
            var updatedItem = new UpdatedItem { EntityType = entityType, EntityId = entityId, ReturnController = returnController };
            Session["UpdatedItem"] = updatedItem;

            return RedirectToAction("UpdatedItem", "Message");
        }

        protected virtual Staff GetCurrentUser()
        {
            var staff =  Context.Staff.SingleOrDefault(x => x.Username == User.Identity.Name.Substring(3, User.Identity.Name.Length - 3)); //remove the domain from the logged in user
            Session["staffId"] = staff.Id; //Set session staff Id for use throughout application
            return staff;
        }
        protected virtual int GetCurrentStaffId()
        {
            var staff = Context.Staff.SingleOrDefault(x => x.Username == User.Identity.Name.Substring(3, User.Identity.Name.Length - 3)); //remove the domain from the logged in user
            Session["staffId"] = staff.Id; //Set session staff Id for use throughout application
            return staff.Id;
        }
        protected virtual DateTime GetWeekStartDate()
        {            
            DayOfWeek currentDay = DateTime.Now.DayOfWeek;
            int daysUntilToday = currentDay - DayOfWeek.Monday;
            DateTime currentWeekStart = DateTime.Now.AddDays(-daysUntilToday);
            return currentWeekStart;
        }

        protected static int GetWeekOfYear(DateTime d)
        {
            
            DayOfWeek day = CultureInfo.InvariantCulture.Calendar.GetDayOfWeek(d);
            if (day >= DayOfWeek.Monday && day <= DayOfWeek.Wednesday)
            {
                d = d.AddDays(3);
            }
            return CultureInfo.InvariantCulture.Calendar.GetWeekOfYear(d, CalendarWeekRule.FirstFourDayWeek, DayOfWeek.Monday);
        }
        public static DateTime FirstDateOfWeek(int year, int weekOfYear)
        {
            DateTime jan1 = new DateTime(year, 1, 1);
            int daysOffset = DayOfWeek.Thursday - jan1.DayOfWeek;

            // Use first Thursday in January to get first week of the year as
            // it will never be in Week 52/53
            DateTime firstThursday = jan1.AddDays(daysOffset);
            var cal = CultureInfo.CurrentCulture.Calendar;
            int firstWeek = cal.GetWeekOfYear(firstThursday, CalendarWeekRule.FirstFourDayWeek, DayOfWeek.Monday);

            var weekNum = weekOfYear;
            // As we're adding days to a date in Week 1,
            // we need to subtract 1 in order to get the right date for week #1
            if (firstWeek == 1)
            {
                weekNum -= 1;
            }

            // Using the first Thursday as starting week ensures that we are starting in the right year
            // then we add number of weeks multiplied with days
            var result = firstThursday.AddDays(weekNum * 7);

            // Subtract 3 days from Thursday to get Monday, which is the first weekday in ISO8601
            return result.AddDays(-3);
        }
    }
}