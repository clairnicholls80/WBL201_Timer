﻿using System;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web.Mvc;
using TimeR.ObjectModel.Entities;
using TimeR.Web.Controllers;
using TimeR.Web.Security;
using TimeR.ObjectModel.Enums;

namespace Timer.Web.Controllers
{
    [TimerAuthorize(Role.Administrator)]

    public class AllocationController : TimerControllerBase //derive this controller from TimerControllerBase to re-use methods
    {
        // GET: Allocation
        public ActionResult Index()
        {
            var allocations = Context.Allocations.ToList().OrderBy(x =>x.Staff.Name).ThenBy(x=>x.Project.ProjectName);
            return View(allocations);
        }

        // GET: Allocation/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Allocation allocation = Context.Allocations.Find(id);
            if (allocation == null)
            {
                return HttpNotFound();
            }
            return View(allocation);
        }

        // GET: Allocation/Create
        public ActionResult Create()
        {
            var model = new Allocation(); //create a new instance of the model
            CacheEntity(model);
            return (IsAjax()) ? (ActionResult)PartialView("Details", model) : View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Allocation model, string submit)
        {
            if (submit != "Cancel") //Check that user has not cancelled out of form
            {
                if (!ModelState.IsValid) //If state IS NOT valid then return the form
                {
                    return IsAjax() ? (ActionResult)PartialView("Details", model) : View(model);
                }
                // get allocation from cache (the cache version will contain details that have been added)
                var item = GetCachedEntity<Allocation>(p => p.Id == model.Id);

                // this merges cached versions without having to use automapper
                UpdateModel(item);
                Context.Allocations.Add(item);
                Context.SaveChanges();
            }
            if (IsAjax()) return Json(new { success = true }); //return 'success' message
            return RedirectToAction("Index");  //return to the Index and refresh the list with the new item in it
        }

        // GET: Allocation/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Allocation allocation = Context.Allocations.Find(id);
            if (allocation == null)
            {
                return HttpNotFound();
            }
            return View(allocation);
        }

        // POST: Allocation/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Allocation allocation)
        {
            if (ModelState.IsValid)
            {
                Context.Entry(allocation).State = EntityState.Modified;
                Context.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(allocation);
        }

        // GET: Allocation/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Allocation allocation = Context.Allocations.Find(id);
            if (allocation == null)
            {
                return HttpNotFound();
            }
            return View(allocation);
        }

        // POST: Allocation/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Allocation allocation = Context.Allocations.Find(id);
            Context.Allocations.Remove(allocation);
            Context.SaveChanges();
            return RedirectToAction("Index");
        }
        protected override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            base.OnActionExecuting(filterContext);

            ViewBag.Staff = Context.Staff.OrderBy(x => x.Name).ToList();
            ViewBag.Projects = Context.Project.OrderBy(x => x.ProjectCombined).ToList();
        }
    }
}
