﻿using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web.Mvc;
using TimeR.ObjectModel;
using TimeR.ObjectModel.Entities;
using TimeR.Web.ViewModels;
using AutoMapper;
using System.Collections.Generic;
using TimeR.ObjectModel.Enums;
using TimeR.Web.Security;

namespace TimeR.Web.Controllers
{
    [TimerAuthorize(Role.Administrator)]
    public class StaffController : TimerControllerBase
    {
        private TimerContext db = new TimerContext();

        // GET: Staff
        public ActionResult Index()
        {
            var model = Context.Staff.ToList();

            return IsAjax() ? (ActionResult)PartialView("List", model) : View(model);
            //return View(db.Staff.ToList());
        }

        // GET: Staff/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Staff staff = db.Staff.Find(id);
            if (staff == null)
            {
                return HttpNotFound();
            }
            return View(staff);
        }

        // GET: Staff/Create
        public ActionResult Create()
        {
            var model = new StaffViewModel();
            var staff = new Staff();
            CacheEntity(staff);
            return (IsAjax()) ? (ActionResult)PartialView("Details", model) : View(model);
        }

        // POST: Staff/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(StaffViewModel model)
        {
            if (!ModelState.IsValid) //If state IS NOT valid then return the form
            {
                return IsAjax() ? (ActionResult)PartialView("Details", model) : View(model);
            }
            // get School from cache (the cache version will contain
            // evcs that have been added)
            var item = GetCachedEntity<Staff>(p => p.Id == model.Id);

            // this merges cached staff with viewmodel without having to use automapper
            UpdateModel(item);
            Context.Staff.Add(item);
            Context.SaveChanges();

            if (IsAjax()) return Json(new { success = true }); //return 'success' message
            return RedirectToAction("Index");  //return to the Index and refresh the list with the new item in it
        }

        // GET: Staff/Edit/5
        public ActionResult Edit(int id)
        {
            var staff = Context.Staff.SingleOrDefault(x => x.Id == id);

            if (staff == null)
            {
                return MissingItemError("Trust", id, "Trust");
            }

            var config = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<Staff, StaffViewModel>();
            });

            IMapper iMapper = config.CreateMapper();

            var model = iMapper.Map<Staff, StaffViewModel>(staff);

            CacheEntity(staff);

            return IsAjax()
                      ? (ActionResult)PartialView("Details", model)
                      : View(model);

            //if (id == null)
            //{
            //    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            //}
            //Staff staff = db.Staff.Find(id);
            //if (staff == null)
            //{
            //    return HttpNotFound();
            //}
            //return View(staff);
        }

        // POST: Staff/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to
        [HttpPost]
        public ActionResult Edit(StaffViewModel model)
        {
            // Throw back if validation errors exist.
            if (!ModelState.IsValid)
            {
                return IsAjax()
                          ? PartialView("Details", model)
                          : (ActionResult)View("Edit", model);
            }

            // get Trust from cache (the cache version will contain
            // details of TrustSchools that have been added or removed)
            var staff = GetCachedEntity<Staff>(p => p.Id == model.Id);

            // set any allocations.projects to null to stop duplicate projects being created
            //foreach (var allocations in staff.Allocations)
            //{
            //    allocations.Project = null;
            //}

            // get Trust from database
            var dbStaff = Context.Staff.Single(x => x.Id == model.Id);

            if (dbStaff == null) return MissingItemError("Staff", model.Id, "Staff");

            // Merges cached Trust with view model
            // to update name of Trust
            UpdateModel(dbStaff);

            // Adds, amends or removes TrustSchools to/from dbTrust
            // prior to Save
            //UpdateStaff(staff, dbStaff);

            Context.SaveChanges();
            return IsAjax() ? (ActionResult)Json(new { success = true }) : RedirectToAction("Index");
            //if (ModelState.IsValid)
            //{
            //    db.Entry(staff).State = EntityState.Modified;
            //    db.SaveChanges();
            //    return RedirectToAction("Index");
            //}
            //return View(staff);
        }

        // GET: Staff/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Staff staff = db.Staff.Find(id);
            if (staff == null)
            {
                return HttpNotFound();
            }
            return View(staff);
        }

        // POST: Staff/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Staff staff = db.Staff.Find(id);
            db.Staff.Remove(staff);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        //private void UpdateStaff(Staff staff, Staff dbStaff)
        //{
        //    // Adds/Amends Allocation in dbStaff
        //    foreach (var allocation in staff.Allocations)
        //    {
        //        if (allocation.Id == 0)
        //        {
        //            dbStaff.Allocations.Add(allocation);
        //        }
        //        else
        //        {
        //            var dbAllocation = Context.Allocations.Find(allocation.Id);
        //            dbAllocation.ProjectId = allocation.Id;
        //        }
        //    }

        //    //// Removes allocations from dbstaff
        //    //var allocationsToDelete = new List<Allocation>();
        //    //foreach (var allocation in dbStaff.Allocations)
        //    //{
        //    //    if (staff.Allocations.FindIndex(x => x.Id == allocation.Id) < 0)
        //    //    {
        //    //        allocationsToDelete.Add(allocation);
        //    //    }
        //    //}
        //    //foreach (var toDelete in allocationsToDelete)
        //    //{
        //    //    Context.Allocations.Remove(toDelete);
        //    //}

        //}
        public ActionResult AllocationList(int id)
        {
            var staff = GetCachedEntity<Staff>(e => e.Id == id);

            if (staff == null) return MissingItemError("Staff", id, "Staff");

            var config = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<Staff, StaffViewModel>();
            });

            IMapper iMapper = config.CreateMapper();

            var model = iMapper.Map<Staff, StaffViewModel>(staff);

            return PartialView(model);
        }
    }
}
    