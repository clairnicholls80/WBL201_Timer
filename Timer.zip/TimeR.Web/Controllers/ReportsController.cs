﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;
using TimeR.Web.Security;
using TimeR.ObjectModel.Enums;
using TimeR.ObjectModel.Entities;
using TimeR.Web.ViewModels;

namespace TimeR.Web.Controllers
{
    [TimerAuthorize(Role.User, Role.Administrator)]
    public class ReportsController : TimerControllerBase
    {
        // GET: Reports
        public ActionResult Index()
        {
            var alloctions = Context.Allocations.Where(x => x.Active == true).ToList();
            var projects = Context.Project.ToList();
            ViewBag.CurrentAllocations = alloctions.Count();
            ViewBag.Projects = projects.Count();
            ViewBag.User= GetCurrentUser();
            return View();
        }

        public ActionResult AllocationReport()
        {
            var alloctions = Context.Allocations.Include(x=>x.Project).Include(x => x.Staff).Where(x=>x.Active==true).ToList();
            return View(alloctions);
        }
        public ActionResult ProjectListReport()
        {
            var projects = Context.Project.OrderBy(x =>x.ProjectName).ToList();
            return View(projects);
        }

        public ActionResult StaffDetailedReport(StaffSearchViewModel model, int? staffList)
        {
            IQueryable<Timesheet> timesheets = Context.Timesheet.Include(x=>x.Staff).Include(x=>x.Project).OrderBy(x => x.Staff.Name).ThenBy(x => x.Project.ProjectName);
            if (staffList >0)
            {
                timesheets = timesheets.Where(x => x.Staff.Id == staffList);
            }            
            if(model.startDate.HasValue ==true && model.endDate.HasValue == true)
            {
                DateTime sDate = model.startDate.Value; //model.startDate.Value;
                DateTime eDate = model.endDate.Value.AddDays(1);                
                timesheets = timesheets.Where(x=>x.Date >= model.startDate && x.Date < eDate);
            }

            model.Timesheets = new List<Timesheet>(timesheets);
            return (IsAjax()) ? (ActionResult)PartialView("_staffDetailedList", model) : View(model);
        }

        public ActionResult StaffConsolidatedReport(StaffSearchViewModel model, int? staffList)
        {
            IQueryable<Timesheet> timesheets = Context.Timesheet.Include(x => x.Staff).Include(x => x.Project).OrderBy(x => x.Staff.Name).ThenBy(x => x.Project.ProjectName);
            if (staffList > 0)
            {
                timesheets = timesheets.Where(x => x.Staff.Id == staffList);
            }
            if (model.startDate.HasValue == true && model.endDate.HasValue == true)
            {
                DateTime sDate = model.startDate.Value; //model.startDate.Value;
                DateTime eDate = model.endDate.Value.AddDays(1);
                timesheets = timesheets.Where(x => x.Date >= model.startDate && x.Date < eDate);
            }

            model.Timesheets = new List<Timesheet>(timesheets);
            return (IsAjax()) ? (ActionResult)PartialView("_staffConsolidatedList", model) : View(model);
        }



        public ActionResult ProjectDetailedReport(ProjectSearchViewModel model, int? projectList)
        {
            IQueryable<Timesheet> timesheets = Context.Timesheet.Include(x => x.Staff).Include(x => x.Project).OrderBy(x => x.Project.ProjectName).ThenBy(x => x.Staff.Name);
            if (projectList > 0)
            {
                timesheets = timesheets.Where(x => x.Project.Id == projectList);
            }
            if (model.startDate.HasValue == true && model.endDate.HasValue == true)
            {
                DateTime sDate = model.startDate.Value; //model.startDate.Value;
                DateTime eDate = model.endDate.Value.AddDays(1);
                timesheets = timesheets.Where(x => x.Date >= model.startDate && x.Date < eDate);
            }

            model.Timesheets = new List<Timesheet>(timesheets);
            return (IsAjax()) ? (ActionResult)PartialView("_projectDetailedList", model) : View(model);
        }

        public ActionResult ProjectConsolidatedReport(ProjectSearchViewModel model, int? projectList)
        {
            IQueryable<Timesheet> timesheets = Context.Timesheet.Include(x => x.Staff).Include(x => x.Project).OrderBy(x => x.Project.ProjectName).ThenBy(x => x.Staff.Name);
            if (projectList > 0)
            {
                timesheets = timesheets.Where(x => x.Project.Id == projectList);
            }
            if (model.startDate.HasValue == true && model.endDate.HasValue == true)
            {
                DateTime sDate = model.startDate.Value; //model.startDate.Value;
                DateTime eDate = model.endDate.Value.AddDays(1);
                timesheets = timesheets.Where(x => x.Date >= model.startDate && x.Date < eDate);
            }

            model.Timesheets = new List<Timesheet>(timesheets);
            return (IsAjax()) ? (ActionResult)PartialView("_projectConsolidatedList", model) : View(model);
        }


        public ActionResult TimesheetReport(TimesheetSearchViewModel model)
        {
            ViewBag.User = GetCurrentUser().Name;
            int staffId = GetCurrentStaffId();
            IQueryable<Timesheet> timesheets = Context.Timesheet.Include(x => x.Staff).Include(x => x.Project).OrderBy(x => x.Date).ThenBy(x => x.Project.ProjectName);
            if (staffId > 0)
            {
                timesheets = timesheets.Where(x => x.StaffId == staffId);
            }
            if (model.startDate.HasValue == true && model.endDate.HasValue == true)
            {
                DateTime sDate = model.startDate.Value; //model.startDate.Value;
                DateTime eDate = model.endDate.Value.AddDays(1);
                timesheets = timesheets.Where(x => x.Date >= model.startDate && x.Date < eDate);
            }

            model.Timesheets = new List<Timesheet>(timesheets);
            return (IsAjax()) ? (ActionResult)PartialView("_staffDetailedList", model) : View(model);
        }



        protected override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            base.OnActionExecuting(filterContext);

            ViewBag.Staff = Context.Staff.OrderBy(x => x.Name).ToList();
            ViewBag.Projects = Context.Project.OrderBy(x => x.ProjectCombined).ToList();
        }
    }
}