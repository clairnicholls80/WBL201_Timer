﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using TimeR.ObjectModel;
using TimeR.ObjectModel.Entities;
using TimeR.ObjectModel.Enums;
using TimeR.Web.Controllers;
using TimeR.Web.Security;
using TimeR.Web.ViewModels;

namespace TimeR.Web.Controllers
{
    [TimerAuthorize(Role.User, Role.Administrator)]
    public class TimesheetController : TimerControllerBase //derive this controller from TimerControllerBase to re-use methods
    {
        public ActionResult Index(int? weekNo)
        {
            var wkNo = 1;
            if (weekNo == null)
            {
                Session["CurrentWeekNo"] = GetWeekOfYear(DateTime.Now);
                wkNo = GetWeekOfYear(DateTime.Now);
            }
            else
            { 
                wkNo = Convert.ToInt32(weekNo); 
            }
            List<Timesheet> model = GetEntries(wkNo);  //Initial load of timesheet screen shows current weeks timesheet
            model = model.OrderBy(x => x.Date).ToList();
            return IsAjax() ? (ActionResult)PartialView("ListEntries", model) : View(model);
        }

        public List<Timesheet> GetEntries( int weekNo)
        {
            var staffId = GetCurrentStaffId(); //get current user to get timesheet codes for.
            var timesheet = Context.Timesheet.Include(x => x.Project).Include(x => x.Staff).Where(x => x.StaffId == staffId).ToList(); //get timesheets for current logged in user
            
            //declare or initialise variables
            int dateWkNo=1;
            int year = DateTime.Now.Year;
            decimal weeklyHours = 0;
            var model = new List<Timesheet>();
            foreach (Timesheet t in timesheet)
            {
                dateWkNo = GetWeekOfYear(t.Date.GetValueOrDefault());
                if (dateWkNo == weekNo)
                {
                    model.Add(t);  //Add timesheet entry to list to return to view
                    weeklyHours += t.Hours; //Running total for hours
                }
                year = t.Date.Value.Year;
            }
            model = model.OrderBy(x => x.Date).ToList();  //Order list by date asc
            ViewBag.WeeklyHours = weeklyHours; //Set weekly hours to display on screen
            ViewBag.ShowingWeekStart = FirstDateOfWeek(year,weekNo).ToLongDateString(); //Get the Monday date for the current week showing
            Session["weekNo"] = weekNo; //Reset session variable before reloading page
            return model;
        }
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Timesheet timesheet = Context.Timesheet.Find(id);
            if (timesheet == null)
            {
                return HttpNotFound();
            }
            return View(timesheet);
        }

        public ActionResult Create()
        {
            var model = new Timesheet();
            model.StaffId = (int)Session["staffId"];
            CacheEntity(model);
            return (IsAjax()) ? (ActionResult)PartialView("Details", model) : View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Timesheet model)
        {
            if (!ModelState.IsValid) //If state IS NOT valid then return the form
            {
                return IsAjax() ? (ActionResult)PartialView("Details", model) : View(model);
            }
            // get allocation from cache (the cache version will contain details that have been added)
            var item = GetCachedEntity<Timesheet>(p => p.Id == model.Id);

            // this merges cached versions without having to use automapper
            UpdateModel(item);
            Context.Timesheet.Add(item);
            Context.SaveChanges();
            if (IsAjax()) return Json(new { success = true }); //return 'success' message
            return RedirectToAction("Index");  //return to the Index and refresh the list with the new item in it

        }

        public ActionResult Edit(int id)
        {
            var timesheet = Context.Timesheet.SingleOrDefault(x => x.Id == id);
            if (timesheet == null) return MissingItemError("Timesheet", id, "Timesheet");
            var config = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<Timesheet, TimesheetViewModel>();
            });
            IMapper iMapper = config.CreateMapper();
            var model = iMapper.Map<Timesheet, TimesheetViewModel>(timesheet);
            //model.Trusts = new SelectList(Context.Trusts.ToList(), "Id", "Name");
            CacheEntity(timesheet);
            return IsAjax()
                      ? (ActionResult)PartialView("Details", model)
                      : View(model);
            //if (id == null)
            //{
            //    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            //}
            //Timesheet timesheet = Context.Timesheet.Find(id);
            //if (timesheet == null)
            //{
            //    return HttpNotFound();
            //}
            //return View(timesheet);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(TimesheetViewModel model, string submit)
        {// Handle cancel.
            if (submit == "Cancel") return RedirectToAction("Index");

            // Throw back if validation errors exist.
            if (!ModelState.IsValid)
            {
                return IsAjax()
                          ? PartialView("Details", model)
                          : (ActionResult)View("Edit", model);
            }

            // get School from cache (the cache version will contain
            // details of EVCs that have been added or removed)
            var item = GetCachedEntity<Timesheet>(p => p.Id == model.Id);
            if (item == null) return MissingItemError("Timesheet", model.Id, "Timesheet");

            //if (!item.RowVersion.SequenceEqual(model.RowVersion)) return UpdatedItemError("VisitType", model.Id, "VisitType"); //check the row version to see if anyone else has edited the record

            //UpdateModel(item);  // update the model
            //Context.SaveChanges();  // save the changes
            // get officer from database
            var dbItem = Context.Timesheet.SingleOrDefault(x => x.Id == model.Id);

            if (dbItem == null) return MissingItemError("Timesheet", model.Id, "Timesheet");

            //if (!dbItem.RowVersion.SequenceEqual(model.RowVersion)) return UpdatedItemError("School", model.Id, "School");

            // Merges cached Trust with view model
            // to update name of Trust
            ////UpdateModel(item);
            // Adds, amends or removes COOfficerVisitTypes to/from dbTrust
            // prior to Save
            //UpdateItem(item, dbItem);
            //Context.SaveChanges();
            dbItem.Date = model.Date;
            dbItem.Description = model.Description;
            dbItem.Hours = model.Hours;
            dbItem.Rate = model.Rate;
            dbItem.Charge = model.Charge;
            
            UpdateModel(dbItem);
            Context.SaveChanges();
            return IsAjax() ? (ActionResult)Json(new { success = true }) : RedirectToAction("Index");  //send success message and return to refreshed list
            //if (ModelState.IsValid)
            //{
            //    Context.Entry(timesheet).State = EntityState.Modified;
            //    Context.SaveChanges();
            //    return RedirectToAction("Index");
            //}
            //return View(timesheet);
        }

        public ActionResult Delete(int id)
        {
            var timesheet = Context.Timesheet.SingleOrDefault(x => x.Id == id);

            if (timesheet == null) return MissingItemError("Timesheet", id, "Timesheet");

            var config = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<Timesheet, TimesheetViewModel>();
            });

            IMapper iMapper = config.CreateMapper();

            //var source = officer;
            var model = iMapper.Map<Timesheet, TimesheetViewModel>(timesheet);

            return (IsAjax()) ? (ActionResult)PartialView("Delete", model) : View(model);
            //if (id == null)
            //{
            //    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            //}
            //Timesheet timesheet = Context.Timesheet.Find(id);
            //if (timesheet == null)
            //{
            //    return HttpNotFound();
            //}
            //return View(timesheet);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(TimesheetViewModel model, string submit)
        {
            if (submit != "Cancel")
            {
                var timesheet = Context.Timesheet.SingleOrDefault(x => x.Id == model.Id);

                if (timesheet == null) return MissingItemError("Timesheet", model.Id, "Timesheet");

                //if (!school.RowVersion.SequenceEqual(model.RowVersion)) return UpdatedItemError("School", model.Id, "School");

                Context.Timesheet.Remove(timesheet);
                Context.SaveChanges();
            }

            if (IsAjax()) return Json(new { success = true });
            return RedirectToAction("Index");
            //Timesheet timesheet = Context.Timesheet.Find(id);
            //Context.Timesheet.Remove(timesheet);
            //Context.SaveChanges();
            //return RedirectToAction("Index");
        }

        protected override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            base.OnActionExecuting(filterContext);

            ViewBag.Staff = Context.Staff.OrderBy(x => x.Name).ToList();
            var loggedInStaff = GetCurrentUser();
            //Include only projects for the current logged in user
            int staffId = loggedInStaff.Id;

            var projectIds = Context.Allocations.Where(x => x.StaffId == staffId).Where(x => x.Active == true).ToList();
            List<Project> projects = new List<Project>();
            if (projectIds != null)
            {
                foreach (var proj in projectIds)
                {
                    Project p = Context.Project.SingleOrDefault(x => x.Id == proj.ProjectId); //lookup the project record
                    projects.Add(p); //add to list to pass to view
                }
            }
            ViewBag.Projects = projects;
        }
        public ActionResult GetRate(string pId)
        {
            //this method is called from the view to calculate the rate
            int r = int.Parse(pId);
            int s = GetCurrentStaffId();
            var rate = Context.Allocations.Where(x => x.ProjectId == r).Where(x => x.StaffId == s).SingleOrDefault(); //Conver the parameter string to an int to look up the rate for the project to pass back to the view

            return Json(rate.Rate);
        }
        //protected void UpdateItem(Timesheet item, Timesheet dbItem)
            // Adds/Amends TrustSchools in dbTrust
    //        foreach (var proj in item.Project)
    //        {
    //            if (proj.Id == 0)
    //            {
    //                dbTrust.Projects.Add(proj);
    //            }
    //            else
    //            {
    //                var dbTrustSchool = Context.TrustSchools.Find(trustSchool.Id);
    //dbTrustSchool.SchoolId = trustSchool.SchoolId;
    //            }
    //        }

    //        // Removes TrustSchools from dbTrust
    //        var trustSchoolsToDelete = new List<TrustSchool>();
    //        foreach (var trustSchool in dbTrust.TrustSchools)
    //        {
    //            if (trust.TrustSchools.FindIndex(x => x.Id == trustSchool.Id) < 0)
    //            {
    //                trustSchoolsToDelete.Add(trustSchool);
    //            }
    //        }
    //        foreach (var trustSchoolToDelete in trustSchoolsToDelete)
    //        {
    //            Context.TrustSchools.Remove(trustSchoolToDelete);
    //        }


    
}
}
