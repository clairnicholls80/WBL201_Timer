﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TimeR.ObjectModel;
using TimeR.ObjectModel.Entities;
using System.Data.Entity;
using TimeR.Web.ViewModels;
using TimeR.ObjectModel.Enums;
using TimeR.Web.Security;

namespace TimeR.Web.Controllers
{
    [TimerAuthorize(Role.User, Role.Administrator)]
    public class HomeController : TimerControllerBase
    {
        public ActionResult Index()
        {
            using (var db = new TimerContext())
            {
                //string loggedInUser = "clnicholls"; //for early testing purposes
                var loggedInStaff = GetCurrentUser();
                if (db.Staff.Any())
                {
                    var user = db.Staff.FirstOrDefault(x => x.Username == loggedInStaff.Username);
                    if (user != null)
                    {
                        string greeting = GetGreeting();                        
                        ViewBag.Message = string.Format("{0} {1}!", greeting, user.Name); //Get message to display in top right hand corner
                        GenerateDashboard(user);
                    }
                    ViewBag.User = loggedInStaff;
                }
            }
            return View();
        }

        private void GenerateDashboard(Staff user)
        {
            //Allocation container
            var allocations = Context.Allocations.Where(x => x.StaffId == user.Id).Where(x => x.Active == true).ToList();
            ViewBag.ActiveProjects = allocations != null ? allocations.Count : 0; //assign active project count for use on home page

            //Weekly Hours and Charge containers
            ViewBag.WeekNo = GetWeekOfYear(DateTime.Now);
            var timesheet = Context.Timesheet.Include(x => x.Project).Include(x => x.Staff).Where(x => x.StaffId == user.Id).ToList(); //get timesheets for current logged in user
            //Get only records for this current week
            int dateWkNo;
            decimal totalHours = 0;
            decimal totalCharge = 0;
            foreach (Timesheet t in timesheet)
            {
                dateWkNo = GetWeekOfYear(t.Date.GetValueOrDefault());
                if (dateWkNo == ViewBag.WeekNo)
                {
                    totalHours += t.Hours;
                    totalCharge += t.Charge;
                }
            }
            ViewBag.WeeklyHours = totalHours;
            ViewBag.WeeklyCharge = totalCharge;

        }

        public string GetGreeting()
        { 
            string greeting = string.Empty;
            if (DateTime.Now.Hour< 12)
            {
                greeting = "Good Morning";
            }
            else if (DateTime.Now.Hour< 17)
            {
                greeting = "Good Afternoon";
            }
            else
            {
                greeting = "Good Evening";
            }
            return greeting;
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}