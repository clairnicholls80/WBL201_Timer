﻿//********************************************************************************
// File: cornwall.js
//
// Notes
// -----
// This javascript file contains functions to aid the use of
// modal popups to achieve creation, update and deletion inside
// of a jQuery Modal Dialog.
//
// The functions contain selectors for specific ids/classes within HTML elements:
//
//    #dialog      : This element will contain the dialog
//    #cancel      : When contained within a dialog this will close the dialog
//    #dialog form : This element will cause a form to be posted via AJAX
//
//********************************************************************************
/*
Prevent caching during ajax interactions,
this is mainly in place due to IE caching
the hell out of ajax calls and causing much chaos.
*/
$.ajaxSetup({ cache: false });

/*
This is the default modal dialog width, set this
variable to the desired value from other code-blocks
if required.
*/
var dialogWidth = 450;

/*
This is the default dialog close button style which will
show the close button in the top right.
*/
var dialogClass = "";

/*
Default dialog position
*/
var dialogPositionY = 20;

/*
This is a place-holder for the function call after the modal
has loaded.
*/
var afterFormLoad = function () { };

/*
This is a place-holder for the function called after a
form has been posted via AJAX.
*/
var afterFormSave = function () { };

/*
This is the placeholder for the function called before
dialog close that enables cancellation of the dialog close
*/
var beforeClose = function () {
    return true;
};

var dialogButton = "";

// Displays a dialog using the link control and title specified
$(document).on("click", ".open-dialog", function () {
    var title = $(this).attr("title");
    if (title == null || title == "") {
        title = $(this).html();
    }
    var viewportWidth = $(window).width();
    // set dialog width to less than viewport size
    if(viewportWidth < dialogWidth) {
       dialogWidthResized = viewportWidth - 100;
    }
    else
    {
       dialogWidthResized = dialogWidth;
    }

    $('#dialog').load($(this).attr("href"), function () {
        dialogButton = "";
        $('#dialog').dialog(
            {
                modal: true,
                title: title,
                width: dialogWidthResized,
                show: "fade",
                hide: "fade",
                resizable: false,
                position: { my: 'top', at: 'center top+40', of: window },
                dialogClass: dialogClass,
                beforeClose: function () { return beforeClose(); }
            });
        afterFormLoad();
    });

    return false;
});

/*
This event binding ensures that a form inside a 
modal dialog is posted via AJAX.
   
Note: After the form has been posted this function
will check if there is a JSON result with a 'success'
property that equates to true, this indicates a successful
POST operation, if anything other than this is returned
then the result of the action is applied to the current
modal dialog.

Multi-part forms may not be supported.
*/
$(document).on('submit', '#dialog form', function () {
    $.ajax(
      {
          url: this.action,
          type: 'POST',
          data: $(this).serialize(),
          success: function (result) {
              if (result.success) {
                  dialogButton = "";
                  $('#dialog').dialog("close");
                  afterFormSave();
              } else {
                  $('#dialog').html(result);
                  afterFormLoad();
              }
          }
      });
    return false;
});

/*
This event binding ensures that a modal dialog closes
when a cancel button inside a modal dialog is clicked.
*/
$(document).on('click', '#dialog #cancel', function () {
    dialogButton = "Cancel";
    $('#dialog').dialog("close");
    return false;
});