﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using TimeR.ObjectModel.Entities;

namespace TimeR.Web.ViewModels
{
    public class TimesheetViewModel:Timesheet
    {
    }
}