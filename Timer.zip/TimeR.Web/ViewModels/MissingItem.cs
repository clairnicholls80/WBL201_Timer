﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Timer.Web.ViewModels
{
    public class MissingItem
    {
        public string EntityType { get; set; }
        public int EntityId { get; set; }
        public string ReturnController { get; set; }
    }
}