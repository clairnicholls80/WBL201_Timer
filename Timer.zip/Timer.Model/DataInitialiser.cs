﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TimeR.ObjectModel
{
    public class DataInitialiser
    {
        public static void Seed(TimerContext context)
        {
            if (context.Staff.Any()) return;
            InitialiseStaff(context);
        }

        private static void InitialiseStaff(TimerContext context)
        {
            if (context.Staff.Any()) return;
            context.Staff.Add(new Entities.Staff { Name = "Clair Nicholls", Username = "clnicholls", Email = "clnicholls@cornwall.gov.uk", Role = Enums.Role.Administrator });
        }
    }
}
