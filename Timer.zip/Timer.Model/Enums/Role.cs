﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TimeR.ObjectModel.Enums
{
    public enum Role
    {
        User, //0
        Administrator //1
    }
}
