﻿using System.Data.Entity.Migrations;

namespace TimeR.ObjectModel.Migrations
{
    internal sealed class Configuration : DbMigrationsConfiguration<TimerContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = true;
            AutomaticMigrationDataLossAllowed = true;
        }

        protected override void Seed(TimerContext context)
        {
            //  This method will be called after migrating to the latest version.

            //  You can use the DbSet<T>.AddOrUpdate() helper extension method
            //  to avoid creating duplicate seed data.
        }
    }
}
