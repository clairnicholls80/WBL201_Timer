﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using TimeR.ObjectModel.Enums;

namespace TimeR.ObjectModel.Entities
{
    public class Staff : EntityBase
    {

        [EmailAddress]
        public string Email { get; set; }

        [Display(Name = "Staff name")]
        public string Name { get; set; }

        [Display(Name = "Username")]
        public string Username { get; set; }

        [Display(Name = "Staff role")]
        public Role Role { get; set; }

    }
}
