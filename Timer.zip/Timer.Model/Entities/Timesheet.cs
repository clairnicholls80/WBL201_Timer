﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TimeR.ObjectModel.Entities
{
    public class Timesheet : EntityBase
    {

        [Display(Name = "User")]
        public int StaffId { get; set; }
       

        [Display(Name = "Project")]
        public int ProjectId { get; set; }


        [Display(Name = "Date")]
        [DisplayFormat(DataFormatString = "{0:d}")]
        public DateTime? Date { get; set; }


        [Display(Name = "Hours")]
        public decimal Hours { get; set; }


        [Display(Name = "Rate")]
        public decimal Rate { get; set; }


        [Display(Name = "Charge")] 
        [DisplayFormat(DataFormatString = "{0:C0}")]
        public decimal Charge { get; set; }


        [Display(Name = "Description")]
        public string Description { get; set; }

        public virtual Staff Staff { get; set; }
        public virtual Project Project { get; set; }

    }
}
