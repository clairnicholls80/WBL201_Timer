﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace TimeR.ObjectModel.Entities
{
    public class Allocation:EntityBase
    {
        public Allocation()
        {
            AllocationGuid = Guid.NewGuid();
        }
        [NotMapped]
        public Guid AllocationGuid { get; set; }

        [Display(Name = "Staff")]
        public int StaffId { get; set; }

        [Display(Name = "Project")]
        public int ProjectId { get; set; }

        [Display(Name = "Staff rate")]
        public decimal Rate { get; set; }

        [Display(Name = "Active")]
        public bool Active { get; set; }

        public virtual Staff Staff { get; set; }
        public virtual Project Project { get; set; }

    }
}
