﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TimeR.ObjectModel.Entities
{
    public class Project : EntityBase
    {
        [Display(Name = "Project code")]
        public string ProjectCode { get; set; }

        [Display(Name = "Project name")]
        public string ProjectName { get; set; }

        [Display(Name = "Target Income")]
        [DisplayFormat(DataFormatString = "{0:C0}")]
        public float? TargetIncome { get; set; }

        //Combine the attributes to save doing this in the view
        [Display(Name = "Project")]
        public string ProjectCombined
        {
            get
            {
                return ProjectName + " (" + ProjectCode + ")";
            }
            set {; }
        }
    }
}
