﻿using System.ComponentModel.DataAnnotations;
using System.Data;

namespace TimeR.ObjectModel.Entities
{
    public abstract class EntityBase
    {
        /// <summary>
        /// The unique record id
        /// </summary>
        [Key]
        public int Id { get; set; }

 
    }
}
