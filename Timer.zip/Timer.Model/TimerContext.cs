﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using TimeR.ObjectModel.Entities;
using TimeR.ObjectModel.Migrations;

namespace TimeR.ObjectModel
{
    public class TimerContext:DbContext
    {
        public TimerContext()
        {
            Database.SetInitializer(new MigrateDatabaseToLatestVersion<TimerContext, Configuration>());
        }
        public DbSet<Staff> Staff { get; set; }
        public DbSet<Project> Project { get; set; }
        public DbSet<Timesheet> Timesheet { get; set; }

        public DbSet<Allocation> Allocations { get; set; }
        public string AuthenticatedUser { get; set; }
    }
}
